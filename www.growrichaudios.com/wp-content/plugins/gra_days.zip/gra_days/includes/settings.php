<?php namespace growrichaudios;
$setting_slug = 'gra_plugin_settings';
\add_filter('piklist_admin_pages', function ($pages) use( $setting_slug ){
    $pages[] = array(
      'page_title' => 'GRA Settings'
      ,'menu_title' => 'GRA Settings'
      ,'sub_menu' => 'edit.php?post_type=gra_month'
      ,'capability' => 'manage_options'
      ,'menu_slug' => $setting_slug
      ,'setting' => $setting_slug
      ,'single_line' => true
      ,'default_tab' => 'Common'
      ,'save_text' => 'Save Settings'
    );

    return $pages;
  });


\add_filter(
  "piklist_pre_update_option_$setting_slug",
  function($new_settings, $settings_delta, $old_settings) {
    if(isset($settings_delta['featured'])){
      \array_splice($new_settings['featured'], 0, 0);
      update_featured_days($new_settings['featured']);
    }else if(isset($settings_delta['update_aws_loader'])){
      update_js_loader();
    }

    return $new_settings;
  },10, 3);





// add_filter('piklist_pre_render_field', function($field){
//   return $field;
// }, 10, 2);
