<?php
add_shortcode( 'gra_content_section', function( $atts, $content = ''){
  if( !isset($atts['type']) ) return '';
  $type = $atts['type'];
  return get_option("gra_${type}_days_html", '');
});
