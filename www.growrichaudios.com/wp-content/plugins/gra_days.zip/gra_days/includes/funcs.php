<?php namespace growrichaudios;

function save_post_handler($post_id, $post, $update){
  if($post->post_type == 'revision' ||
    $post->post_type != 'page' ||
    \get_post_meta($post_id, 'gra_page_to_use_as', true) != 'gra_year')
      return;

  $menu = get_years_months_menu();

  save_files_to_storage([
    [
      'Key' => 'menu.html',
      'Body' => $menu,
      'ContentType' => 'text/html'
    ]
  ]);

}

function get_years_months_menu(){
  $year_pages = \get_posts([
    'posts_per_page' => -1,
    'post_type' => 'page',
    'orderby' => 'menu_order date',
    'order' => 'ASC',
    'meta_query' => [[
        'key' => 'gra_page_to_use_as',
        'value' => 'gra_year'
      ]]
    ]);

  $menu = '<div class="gra-menu-container">';
  foreach($year_pages as $page){
    $menu .= '<div class="gra-menu-item-year-wrap">';
    $menu .= '<div class="gra-menu-item-year">' . $page->post_title . '</div>';
    $months = \array_filter(\get_post_meta($page->ID, 'gra_months_group', true));
    if(!count($months)) $months = [];
    $menu .= '<div class="gra-menu-section">';
    foreach($months as $month => $month_post_id){
      $menu .= '<div class="gra-menu-item-month-wrap">';
      $menu .= '<div class="gra-menu-item-month" data-gra-month-id="' . $month_post_id . '">' . $month . '</div>';
      $menu .= '<div class="gra-menu-section"></div>';
      $menu .= '</div>';
    }
    $menu .= '</div></div>';
  }
  $menu .= '</div>';
  return $menu;
}


function save_gra_month($post_id, $post, $update) {
  update_month($post);
  maybe_update_recent($post);
  // maybe_update_featured($post);
}

function update_month($post){
  $month_id = $post->ID;
  $days = \get_post_meta($month_id, 'gra_days_group', true);
  if(!$days) return;
  foreach($days as &$day){
    $day_number = \ltrim($day['day_number'], '0');
    $day_number_zero_padded = \str_pad($day_number, 2, 0, STR_PAD_LEFT);
    $day['uid'] = $month_id . $day_number_zero_padded;
    $day['slug'] = \sanitize_title($day_number_zero_padded . '-' . $day['title']);
    $day['day_number'] = $day_number;
  }

  \array_splice($days, 0, 0);
  \update_post_meta( $month_id, 'gra_days_group', $days );

  save_files_to_storage([
    [
      'Key' => 'months/' . $post->ID,
      'Body' => template\get_days_html($days),
      'ContentType' => 'text/html'
    ]
  ]);
}

function update_content($days, $wp_option_name){
  // \update_option($wp_option_name, $days);
  $html = template\get_days_html($days);
  \update_option($wp_option_name . '_html', $html);
  save_files_to_storage([
    [
    'Key' => $wp_option_name . '.html',
    'Body' => $html,
    'ContentType' => 'text/html'
    ]
  ]);
}

function maybe_update_recent($gra_month_post){
  $gra_settings = \get_option('gra_plugin_settings', []);
  $how_many_to_add_left = get_or($gra_settings['recent_number'], 10);

  $wp_option_name = 'gra_recent_days';
  $query_offset = 0;
  $recent_to_save = [];
  $is_update_needed = false;
  $query_args = [
    'numberposts' => 1,
    'offset'      => $query_offset,
    'orderby'     => 'post_date_gmt',
    'order'       => 'DESC',
    'post_type'   => 'gra_month',
    'post_status' => 'publish' #with 'any' order is messed up
  ];

  do {
    $query_args['offset'] = $query_offset++;
    if($gra_cur_months = \get_posts($query_args) and isset($gra_cur_months[0]))
      $gra_cur_month = $gra_cur_months[0];
    else
      break;

    if(!$is_update_needed && ($gra_cur_month->ID == $gra_month_post->ID)) $is_update_needed = true;
    //if($gra_cur_month->post_status != 'publish') continue; #if qeury post_status=any
    $days = array_reduce(
      \get_post_meta($gra_cur_month->ID, 'gra_days_group', true),
      function($acc, $day) use ($gra_cur_month){
        if(empty($day['title'])) return $acc;
        $acc[] = $day;

        return $acc;},
      []
    );

    if(!isset($days[0])) continue;
    $days = array_slice(array_reverse($days), 0, $how_many_to_add_left);
    $how_many_to_add_left -= count($days);
    $recent_to_save += $days;

  } while ($how_many_to_add_left > 0);

  if($is_update_needed)
    update_content($recent_to_save, $wp_option_name);
}

function update_featured_days(&$pairs){
  $featured_days = [];
  foreach($pairs as &$pair){
    $month_id = $pair['month_id'];
    $day_number = $pair['day_number'] = \ltrim($pair['day_number'], '0');

    $days = \get_post_meta($month_id, 'gra_days_group', true);
    $days = \array_filter($days, function($day) use ( $day_number ){
      return $day['day_number'] == $day_number;
    });

    $featured_days = \array_merge($featured_days, $days);
  }

  \count($featured_days) and
    update_content($featured_days, 'gra_featured_days');
}

function maybe_update_featured($gra_month_post){
  $gra_settings = \get_option('gra_plugin_settings', false);
  if(!$gra_settings) return;

  $featured_pairs = get_or($gra_settings['featured'], false);
  if(!$featured_pairs) return;

  foreach($featured_days as $pair){
    if($pair['month_id'] == $gra_month_post->ID){
      update_featured_days($featured_days);
      return;
    }
  }

}

function update_js_loader(){
  $assets_dir = \dirname(__DIR__) . '/assets/';

  $gra_settings = \get_option('gra_plugin_settings', []);
  $aws = $gra_settings['aws'];
  $aws_path = 'https://s3.amazonaws.com/' . $aws['bucket'] . '/' . (empty($aws['subfolder'])? '': $aws['subfolder'] . '/');

  $css = str_replace("\\", "\\\\",
    \preg_replace(
      "/[\r\n]+/", '', \file_get_contents($assets_dir . 'style.css') . '.video-js { opacity: 0; }'));
  save_files_to_storage([
    [
    'Key' => 'loader.js',
    'Body' => \str_replace(
      [
        '%aws_path%',
        '%additional_css%',
        '/*%main_script%*/'
      ],
      [
        $aws_path,
        $css,
        \file_get_contents($assets_dir . 'script.js')
      ],
      \file_get_contents($assets_dir . 'loader.js')),
    'ContentType' => 'application/javascript'
    ]
  ]);

}

function get_month_days(){
  $month_id = $_GET['data'];
  $days = \get_post_meta($month_id, 'gra_days_group', true);
  if(!$days) \wp_send_json(['error' => "gra_days_group option for $month_id missing"]);
  // \wp_send_json(\array_column($days, 'title'));
  \wp_send_json($days);
}

function get_or(&$val, $default = false){
  return empty($val)? $default: $val;
}


function save_files_to_storage(array $files /* [Key, Body, ContentType] */){
  // $dir = 'c:/Users/John/Documents/xampp/htdocs/11/';
  // \file_put_contents($dir . $files[0]['Key'], $files[0]['Body']);
  upload_files_to_aws_s3($files);
}

function upload_files_to_aws_s3($files){
  $gra_settings = \get_option('gra_plugin_settings', []);
  $aws = $gra_settings['aws'];
  if(empty($aws['is_enabled']) || empty($files)) return;

  require_once 'aws.phar';

  $aws_config = [
    'version'     => '2006-03-01',
    'region'      => $aws['region'],
    // 'scheme'      => 'http',
    'credentials' => [
      'key'    => $aws['key'],
      'secret' => $aws['secret']
      ]
  ];

  $s3 = \Aws\S3\S3Client::factory($aws_config);
  $region = $s3->getBucketLocation(['Bucket' => $aws['bucket']])->get('LocationConstraint');
  if($region != $aws_config['region']){
    $aws_config['region'] = $region;
    $s3 = \Aws\S3\S3Client::factory($aws_config);
  }


  if(!empty($aws['subfolder'])){
    foreach($files as &$file) $file['Key'] = $aws['subfolder'] . '/' . $file['Key'];
  }
  foreach($files as $file){
    try{
      $result = $s3->putObject([
          'Bucket' => $aws['bucket'],
          // 'ACL' => 'public-read'
        ] + $file);
    }catch (\Aws\S3\Exception\S3Exception $e){
      $msg = [
        'type' => 'error',
        'text' => 'AWS S3 ' . $e->getMessage() . '<br>' . $aws['bucket'] . '/' . $file['Key']
      ];
      //TODO maybe use array of notices, so update existing notices.
      \update_option('gra_admin_notices', $msg);
      return;
    }
  }

}
