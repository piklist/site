<?php
add_filter('query_vars', function($query_vars){
    $query_vars[] = 'gra-query';
    return $query_vars;
});

// add_action( 'template_redirect', 'gra_ajax_redirect' );
// function gra_ajax_redirect(){
//   $ajax_query = get_query_var('gra-query');
//   if(!$ajax_query) return;
//   include 'get_month_days_list.php';
//
//   exit;
// }
