<?php namespace growrichaudios\template;
function get_page_parts_tmpl(){
  $post = \get_post();
  $month_pages = \get_post_meta($post->ID, 'gra_months_group', true);

  $gra_query = explode('-', \get_query_var('gra-query'), 2);
  $query_month = $gra_query[0];
  $query_day_slug = isset($gra_query[1])? $gra_query[1]: null;

  $queryKey_title_pair_items = [];

  $OUT = [];
  if(isset($month_pages[$query_month])){
    $month_id = $month_pages[$query_month];
    $days_meta = \get_post_meta($month_id, 'gra_days_group', true);

    $day_to_show_idx = null;
    $current_day_menu_item_query = null;
    foreach($days_meta as $idx => $day_meta){
      $item_query = '?gra-query='.$query_month.'-'.$day_meta['slug'];
      $queryKey_title_pair_items[$item_query] = \apply_filters('the_title', $day_meta['day_number'] . ' - ' . $day_meta['title']);
      if($query_day_slug && $query_day_slug == $day_meta['slug']){
        $day_to_show_idx = $idx;
        $current_day_menu_item_query = $item_query;
      }
    }

    if(isset($day_to_show_idx)){
      $choosen_day_meta = $days_meta[$day_to_show_idx];
      $OUT['title'] = \apply_filters('the_title',
        // $query_month . ' ' . $choosen_day_meta['day_number'] . ' - ' . $choosen_day_meta['title']);
        $choosen_day_meta['title']);
      $OUT['menu'] = get_menu_items_tmpl(
        \get_permalink($post->ID) . '?gra-query=' . $query_month,
        $query_month,
        $queryKey_title_pair_items,
        $current_day_menu_item_query);
      $OUT['content'] = get_day_html(get_sanitized_day_meta($choosen_day_meta));
    }else{
      $OUT['title'] = $query_month;
      $OUT['menu'] =  get_menu_items_tmpl(
        \get_permalink($post->ID),
        $post->post_title,
        $queryKey_title_pair_items);
      $OUT['content'] = \apply_filters('the_content', \get_post($month_id)->post_content);
    }
  }else{
    $OUT['title'] = $post->post_title;
    foreach($month_pages as $month => $day_page_id)
      if($day_page_id) $queryKey_title_pair_items['?gra-query='.$month] = $month;
    $OUT['menu'] = get_menu_items_tmpl(
      \get_permalink($post->post_parent),
      \apply_filters('the_title', \get_post($post->post_parent)->post_title),
      $queryKey_title_pair_items);
    $OUT['content'] = \apply_filters('the_content', $post->post_content);
  }
  return $OUT;
}


function get_menu_items_tmpl($go_back_href, $go_back_title, $items, $current_menu_item_key = null){
  $menu_item_template = '<li class="%s"><a href="%s">%s</a></li>';
  $out = '';

  $out .= sprintf($menu_item_template, 'page_item', $go_back_href, 'Back to '.$go_back_title);
  foreach($items as $query => $item_title){
    if ($current_menu_item_key && $query == $current_menu_item_key)
      $out .= sprintf($menu_item_template, 'page_item current_page_item', $query, $item_title);
    else
      $out .= sprintf($menu_item_template, 'page_item', $query, $item_title);
  }
  return $out;
}

function get_days_html($days){
  $html = '<div class="gra-days-container">';
  foreach($days as $day){
    $html .= get_day_html(get_sanitized_day_meta($day));
  }
  $html .= '</div>';
  return $html;
}

function get_player_html($file = ' ', $day_id = 0){
  ob_start();
  ?>
  <audio id="gra-player-<?php echo $day_id ?>" class="video-js" controls preload="none" data-setup='{}'>
    <source src="<?php echo $file ?>" type='audio/mp3'>
    <p class="vjs-no-js">
      To view this video please enable JavaScript, and consider upgrading to a web browser that
      <a href="http://videojs.com/html5-video-support/" target="_blank">supports HTML5 video</a>
    </p>
  </audio>
  <?php
  return ob_get_clean();
}

function get_day_html($day, $is_content_collapsed = false){
  list(
    $day_number,
    $uid,
    $title,
    $content,
    $image,
    $file,
  ) = ['', '', '', '', '', ' '];
  extract($day, EXTR_IF_EXISTS);
  ob_start();
  ?><div class="gra-day-container" data-day-number="<?php echo $day_number ?>">
    <?php if( $title ): ?>
      <div class="gra-day-title"><?php echo $title ?></div>
    <?php endif; ?>
      <div class="gra-day-content-row">
      <?php if( empty($image) ): ?>
        <div class="gra-day-text"><?php echo $content ?></div>
      <?php elseif( empty($content) ): ?>
        <div style="text-align:center"><img class="gra-day-image" src="<?php echo $image ?>"></div>
      <?php else: ?>
        <div class="gra-day-image-wrap"><img class="gra-day-image" src="<?php echo $image ?>">
        </div><div class="gra-day-text-wrap"><div class="gra-day-text"><?php echo $content ?></div></div>
      <?php endif; ?>
      </div>
      <?php echo get_player_html($file, $uid) ?>
      <div class="gra-day-download-wrap">
        <strong>Download MP3 Audio</strong></br>
        <a href="<?php echo $file ?>" target="_self">Right click this link</a>, and select "Save As" to download audio
      </div>
    </div><?php

  return ob_get_clean();
}

function get_sanitized_day_meta($day){
  $day['uid'] = \esc_attr($day['uid']);
  $day['day_number'] = \esc_attr($day['day_number']);
  isset($day['title']) and $day['title'] = \apply_filters('the_title', $day['title']);
  isset($day['content']) and $day['content'] = \apply_filters('the_content', $day['content']);
  isset($day['file']) and $day['file'] = \esc_url($day['file']);
  isset($day['image']) and $day['image'] = \esc_url($day['image']);
  return $day;
}
