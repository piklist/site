<?php add_action( 'init', function() {
  $MonthLabels = array(
    'name' => __( 'Months'),
    'singular_name' => __( 'Months'),
    'all_items' => __( 'All Months'),
    'add_new' => __( 'Add New Month'),
    'add_new_item' => __( 'Add New Month'),
    'edit_item' => __( 'Edit Month'),
    'new_item' => __( 'New Month'),
    'view_item' => __( 'View Months'),
    'not_found' => __( 'No Months found'),
    'not_found_in_trash' => __( 'No Months found in Trash'),
    'parent_item_colon' => ''
	);

  $MonthArgs = array(
    'description'         => '',
    'labels'              => $MonthLabels,
    'public'              => false,
    'exclude_from_search' => false,
    'show_ui'             => true,
    'show_in_nav_menus'   => true,
    'hierarchical'        => false,
    'supports'            => ['title', 'editor', 'thumbnail'],
    'has_archive'         => false,
    'rewrate'             => false,
    'query_var'           => false,
	);

	register_post_type('gra_month', $MonthArgs);
}
);


add_action('save_post_gra_month', 'growrichaudios\save_gra_month', 100, 3);
