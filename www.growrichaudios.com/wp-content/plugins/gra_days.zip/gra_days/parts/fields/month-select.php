<script>
(function($){
  $(document).ready(function(){
    var $selected_input;
    var $months = $('.gra-month-selector');

    $('.gra_plugin_settings_featured_month_id').each(function(i,el){
      var title = $months.find('option[value="' + el.value + '"]').html();
      var field_group_id = $(el).data('piklist-field-group');
      $('.gra-month-selector-title[data-piklist-field-group="' + field_group_id + '"]').val(title)
    });

    $('.form-table').on('click', '.gra-month-selector-title', function(e){
      var $el = $(e.target);
      $selected_input = $el;
      var offset = $el.offset();
      var select_value = $el.parent().parent().find('.gra_plugin_settings_featured_month_id').val()
      $months.val(select_value).show().offset({top: offset.top, left: offset.left}).outerWidth($el.outerWidth());
    });

    $months.on('change', function(e){
      var month_id = $months.val();
      $selected_input.val($months.find('option:selected').html());
      $selected_input.parent().parent().find('.gra_plugin_settings_featured_month_id').val(month_id);
      $months.hide();
      // get_month_days(month_id);
    });
  });

  function get_month_days(month_id){
    $.get(
      ajaxurl,
      {
        'action': 'gra_get_month_days',
        'data':   month_id
      }
    ).then(function(data){
      console.log(data);
    });
  }

}(jQuery));
</script>


<?php
$choices = piklist(
  get_posts([
    'post_type' => 'gra_month'
    ,'numberposts' => -1
    ,'orderby' => 'title'
    ,'order' => 'DESC'
  ]),
  ['ID', 'post_title']
);

$html = '';
foreach ($choices as $id => $title){
  $html .= '<option value="' . $id . '">' . $title . '</option>';
}

?><select size="16" class="gra-month-selector" style="display:none;position:absolute;z-index:999;height:300px"><?php echo $html ?>>
