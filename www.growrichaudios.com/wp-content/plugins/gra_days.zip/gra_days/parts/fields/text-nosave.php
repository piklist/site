<input
  type="text" 
  <?php echo piklist_form::attributes_to_string($attributes); ?>
/>
