<?php
/*
Title: Update HBA loader
Setting: gra_plugin_settings
Order: 5
Tab: Loader
*/

piklist('field', array(
    'type' => 'hidden',
    'field' => 'update_aws_loader'
  ));
