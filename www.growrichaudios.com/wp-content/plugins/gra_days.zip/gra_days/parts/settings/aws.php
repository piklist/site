<?php
/*
Title: AWS S3 settings
Setting: gra_plugin_settings
Order: 1
Tab: AWS
*/
piklist('field', [
    'type' => 'group'
    ,'field' => 'aws'
    ,'label' => 'AWS'
    ,'fields' => [
      [
        'label' => 'Enabled'
        ,'columns' => 12
        ,'field' => 'is_enabled'
        ,'type' => 'checkbox'
        ,'choices' => [
          '1' => 'Enable'
        ]
      ],
      [
        'label' => 'Key'
        ,'columns' => 4
        ,'field' => 'key'
        ,'type' => 'text'
      ],
      [
        'label' => 'Secret'
        ,'columns' => 8
        ,'field' => 'secret'
        ,'type' => 'text'
      ],
      [
        'label' => 'Region'
        ,'columns' => 4
        ,'field' => 'region'
        ,'type' => 'text'
      ],
      [
        'label' => 'Bucket'
        ,'columns' => 4
        ,'field' => 'bucket'
        ,'type' => 'text'
      ],
      [
        'label' => 'Subfolder'
        ,'columns' => 4
        ,'field' => 'subfolder'
        ,'type' => 'text'
      ]
    ]
  ]);
