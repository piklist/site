<?php
/*
Title: Common settings
Setting: gra_plugin_settings
Order: 1
Tab: Common
*/
piklist('field', array(
    'type' => 'number'
    ,'field' => 'recent_number'
    ,'label' => 'How many days in recent'
    ,'description' => 'To update recent content, update (re-save) the latest Month post'
    // ,'help' => 'This is help text.'
    ,'columns' => 12
    ,'value' => 10
    // ,'attributes' => array(
    //   'class' => 'text'
    // )
  ));

// piklist('field', array(
//     'type' => 'textarea'
//     ,'field' => 'day_container_css'
//     ,'label' => 'Day container css'
//     ,'columns' => 12
//     ,'attributes' => array(
//       'rows' => 20
//     )
//   ));
