<?php
/*
Title: Featured days
Setting: gra_plugin_settings
Order: 2
Tab: Featured
*/

piklist('field', [
  'type' => 'month-select'
]);



piklist('field', [
    'type' => 'group'
    ,'field' => 'featured'
    ,'label' => 'Featured'
    ,'add_more' => true
    ,'fields' => [
      [
        'type' => 'hidden'
        ,'field' => 'month_id'
      ],
      [
        'label' => 'Month'
        ,'type' => 'text-nosave'
        ,'columns' => 3
        ,'attributes' => [
          'class' => 'gra-month-selector-title'
        ]
      ],
      [
        'label' => 'Day'
        ,'field' => 'day_number'
        ,'type' => 'number'
        ,'columns' => 1
      ]

    ]
  ]);
