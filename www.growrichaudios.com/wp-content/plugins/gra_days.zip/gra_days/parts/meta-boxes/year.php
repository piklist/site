<?php
/*
Title: Months of the year
Post Type: page
*/
$choices = piklist(
  get_posts([
    'post_type' => 'gra_month'
    ,'numberposts' => -1
    ,'orderby' => 'title'
    ,'order' => 'ASC'
  ]),
  ['ID', 'post_title']
);

$choices = ['' => '-'] + $choices;
$months = array(
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December'
);

$fileds = array();
foreach($months as $month){
  $fields[] = array(
    'type' => 'select'
    ,'field' => $month
    ,'label' => $month
    ,'choices' => $choices
    ,'columns' => 3
  );
}

piklist('field', array(
  'type' => 'select'
  ,'field' => 'gra_page_to_use_as'
  ,'label' => 'Page role'
  ,'choices' => array(
    'default' => 'OptimizePress default'
    ,'gra_year' => 'Year'
  )
  ,'value' => 'default'
));

piklist('field', array(
  'type' => 'group'
  ,'field' => 'gra_months_group'
  ,'label' => 'Months'
  // ,'template' => 'field'
  ,'fields' => $fields
  ,'conditions' => array(
    array(
      'field' => 'gra_page_to_use_as'
      ,'value' => 'gra_year'
    )
  )
));
