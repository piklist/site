<?php
/*
Title: Days
Post Type: gra_month
Order: 20
*/

piklist('field', [
    'type' => 'group'
    ,'field' => 'gra_days_group'
    ,'label' => 'Days'
    ,'add_more' => true
    ,'template' => 'field'
    ,'fields' => [
      [
        'type' => 'number'
        ,'field' => 'day_number'
        ,'label' => 'Day'
        ,'columns' => 1
      ],
      [
        'type' => 'text'
        ,'field' => 'title'
        ,'label' => 'Title'
        ,'columns' => 11
      ]
      // ,[
      //   'type' => 'checkbox'
      //   ,'field' => 'is_featured'
      //   ,'label' => 'Featured?'
      //   ,'columns' => 2
      //   ,'value' => 1
      //   , 'choices' => [
      //     1 => 'yes',
      //   ]
      // ]
      ,array(
        'type' => 'editor'
        ,'field' => 'content'
        ,'label' => 'Content'
        ,'template' => 'field'
        ,'columns' => 12
        ,'options' => array(
          'quicktags' => true
          // 'media_buttons' => true
        )
      )
      // ,array(
      //   'type' => 'textarea'
      //   ,'field' => 'script'
      //   ,'label' => 'Javascript snippet'
      //   ,'columns' => 12
      // )
      ,[
        'type' => 'text'
        ,'field' => 'file'
        ,'label' => 'Audio link'
        ,'columns' => 12
      ]
      ,[
        'type' => 'text'
        ,'field' => 'image'
        ,'label' => 'Image link'
        ,'columns' => 12
      ]
    ]
  ]);
