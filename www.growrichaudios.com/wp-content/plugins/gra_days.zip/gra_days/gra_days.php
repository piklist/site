<?php
/*
Plugin Name: GrowRichAudio content
Description: Depends on Piklist >0.9.9.8
Plugin Type: Piklist
*/

//gra = GrowRichAudios
if ( ! defined( 'WPINC' ) ) die;
include 'includes/register_query_var.php';

include 'includes/shortcodes.php';
//include 'includes/update.php';
include 'includes/template_functions.php';

$dir = plugin_dir_path(__FILE__);
add_action('wp_head', function() use($dir){
  echo '<link href="https://vjs.zencdn.net/5.10.7/video-js.css" rel="stylesheet">';
  echo '<link href="' . plugin_dir_url( __FILE__ ) . 'assets/style.css" rel="stylesheet">';
  // echo '<script src="http://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>';
  echo '<script>' . file_get_contents( $dir . 'assets/script-head.js') . '</script>';
});

add_action('wp_footer', function() use($dir){
  echo '<script src="https://vjs.zencdn.net/5.10.7/video.js"></script>';
  echo '<script>' . file_get_contents( $dir . 'assets/script.js') . '</script>';
});


if ( ! is_admin() ) return;

include 'includes/funcs.php';
include 'includes/month_posttype.php';
include 'includes/settings.php';

// add_action( 'wp_ajax_gra_get_month_days', 'growrichaudios\get_month_days' );

add_action( 'admin_notices', function(){
    $notice = get_option('gra_admin_notices');
    if($notice){
      $text = '<strong>GRA</strong><br>' . $notice['text'];
      printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>', $notice['type'], $text );
      delete_option('gra_admin_notices');
    }
  }, 50);

add_action('save_post', '\growrichaudios\save_post_handler', 101, 3);

function my_custom_init() {
  remove_post_type_support( 'page', 'custom-fields' );
}
add_action( 'init', 'my_custom_init' );