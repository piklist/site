<script>
if(!document.gra_init){
  document.gra_init = {
    get: function(page, selector){
      setTimeout(function(){
        document.gra_init.get(page, selector);
      }, 60);
    }
  };
  var script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = 'https://s3.amazonaws.com/demozone/sync/loader.js';
  var head_tag = document.head || document.getElementsByTagName('head')[0];
  head_tag.appendChild(script);
}
</script>
