(function(window, undefined){
	var document = window.document;
	document.gra_init = {
		aws_path: '%aws_path%',
		menu_loaded: document.gra_init.menu_loaded,
		get: document.gra_init.get
	};
	var script = document.createElement( 'script' );
	script.type = 'text/javascript';
	script.onload = function(){
		head.load([
			'https://vjs.zencdn.net/5.10.7/video-js.css',
			'https://vjs.zencdn.net/5.10.7/video.js',
			], function(){
				$('<style type="text/css">%additional_css%</style>').appendTo('head');
				/*%main_script%*/
			});
	};
	script.src = 'https://cdnjs.cloudflare.com/ajax/libs/headjs/1.0.3/head.min.js';
	var head_tag = document.head || document.getElementsByTagName('head')[0];
	head_tag.appendChild(script);
}(window));
