jQuery(document).ready(function($, undefined){
  var getSeekButton = (function(){
    var videoJsButtonClass = videojs.getComponent('Button');
    var seekButton =  videojs.extend(videoJsButtonClass, {
      constructor: function(title, delta, player_instance) {
        videoJsButtonClass.call(this, player_instance);
        this.player_instance = player_instance;
        this.el().innerHTML = title;
        this.el().dataset.delta = delta;
      },
      handleClick: function(){
        var player_instance = this.player_instance;
        var delta = parseInt(this.el().dataset.delta);
        var time = player_instance.currentTime();
        time = time + delta
        if(time < 0) time = 0
        else if(time > player_instance.duration()) time = player_instance.duration();
        player_instance.currentTime(time);
      }
    });
    return function(title, delta, player_instance){
      return new seekButton(title, delta, player_instance);
    }
  }());
  var player_init = function (){
    var player_instance = this;
    // augment control bar with +-30 sec buttons
    var control_bar = player_instance.getChild('controlBar');
    control_bar.el().insertBefore(
      getSeekButton('-30 s', -30, player_instance).el(),
      control_bar.getChild('playToggle').el());
    control_bar.el().insertBefore(
      getSeekButton('+30 s', 30, player_instance).el(),
      control_bar.getChild('muteToggle').el());
    var split_div = document.createElement('div');
    split_div.className = 'vjs-control-bar-splitter';
    control_bar.el().insertBefore(
      split_div, control_bar.getChild('currentTimeDisplay').el());

    // prepare player initial look
    var initial_src = $(player_instance.el()).find('.vjs-tech').attr('src');
    if (initial_src == ' ')
      $(control_bar.el()).find('button').prop('disabled', true);
      setTimeout(function(){
        player_instance.addClass('vjs-has-started');
        player_instance.el().style.opacity = 1;
      }, 50);
    //pause all other player instances when play button is clicked
    player_instance.on('play', function(e){
      $.each(videojs.getPlayers(), function(index, player){
        if (player && player.id() != e.target.id) player.pause();
      });
    });
  };

  var player_config = {
    playbackRates: [0.75, 1, 1.25, 1.5, 2],
    children: [
      'mediaLoader', 'errorDisplay',
      {
        name: 'controlBar',
        children: [
          'playToggle', 'muteToggle', 'volumeControl', 'playbackRateMenuButton',
          'currentTimeDisplay', 'timeDivider', 'durationDisplay', 'progressControl',
          'remainingTimeDisplay', 'customControlSpacer',
        ]
      }
    ]
  };


  var STATE = {
    is_animating: false,
    current_month_html: '',
    $spinner: $('<div class="gra-spinner"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div>')
  }

  var page_loaded = function(data, selector){
    $.each(videojs.getPlayers(), function(i, p){p && p.dispose();});
    $(selector).html(data).find('.gra-day-container .video-js')
    .each(function(i, player){
      videojs(player, player_config).ready( player_init );
    });
  };


  var month_loaded = function(data, selector, $others){
    $.each(videojs.getPlayers(), function(i, p){p && p.dispose();});
    var day_titles = '', day_number, $el;
    STATE.is_animating = false;
    STATE.current_month_html = data;
    $(STATE.current_month_html).children().each(function(i,el){
      $el = $(el);
      day_number = $el.data('day-number');
      day_titles += '<div><div class="gra-menu-item-day" data-day-number="' + day_number + '">' +
        day_number + ' &#8211; ' + $el.find('.gra-day-title').html() + '</div></div>';
    });
    $others.slideUp();
    $(selector).html(day_titles).slideDown(400, function(){
      STATE.is_animating = false;
    });

  }

  var handle_click_year = function($clicked){
    STATE.is_animating = true;
    var is_same_item = $clicked.hasClass('gra-menu-active')? true: false;
    $('.gra-menu-item-year.gra-menu-active').removeClass('gra-menu-active').next().slideUp(400, function(){STATE.is_animating = false;})
    is_same_item || $clicked.addClass('gra-menu-active').next().slideDown(400, function(){STATE.is_animating = false;});
  }
  var handle_click_month_or_day = function($clicked, cb){
    STATE.is_animating = true;
    if($clicked.hasClass('gra-menu-active')){
      $clicked.removeClass('gra-menu-active').next().slideUp();
      var $clicked_wrap = $clicked.parent();
      var $prev = $clicked_wrap.prev();
      var $next = $clicked_wrap.next();
      var $prev_and_next = $prev.add($next);
      if($prev_and_next.length){
        $prev_and_next.slideDown(400, function(){
          $prev_and_next.animate({opacity:1},
            function(){$prev_and_next.contents().unwrap();STATE.is_animating = false;});
        });
      }else{
        STATE.is_animating = false;
      }

    }else{
      $clicked.addClass('gra-menu-active');
      $clicked.hasClass('gra-menu-item-month') && $clicked.append(STATE.$spinner);
      var $others_prev = $($clicked.parent().prevAll().get().reverse()).wrapAll('<div>').parent();
      var $others_next = $clicked.parent().nextAll().wrapAll('<div>').parent();;
      var $others = $others_prev.add($others_next);
      $others.animate({opacity:0}).promise().done(function(){
        cb && cb($clicked, $others)
      });
    }
  }

  var menu_loaded = function(data, selector){
    $(selector).html(data);
    if(document.gra_init.is_menu_initiated) return;
    document.gra_init.is_menu_initiated = true;

    $(document).on('click.gra', '.gra-menu-container', function(e){

      if(STATE.is_animating) return;
      var $clicked = $(e.target);

      if($clicked.hasClass('gra-menu-item-year')){

        handle_click_year($clicked);

      }else if($clicked.hasClass('gra-menu-item-month')){

        handle_click_month_or_day($clicked, function($clicked, $others){
          document.gra_init.get('months/' + $clicked.data('gra-month-id'),
            '.gra-menu-item-month.gra-menu-active + .gra-menu-section',
            function(data, selector){
              month_loaded(data, selector, $others)
            },
            function(){handle_click_month_or_day($clicked)});
        });

      }else if($clicked.hasClass('gra-menu-item-day')){

        handle_click_month_or_day($clicked, function($clicked, $others){
          if(!$clicked.next('.gra-day-container')[0]){
            $clicked.after($(STATE.current_month_html).find('.gra-day-container[data-day-number="' + $clicked.data('day-number') + '"]').hide());
            $clicked.next().find('.video-js').each(function(i, player){
              videojs(player, player_config).ready( player_init );
            });
          }
          $others.slideUp();
          $clicked.next().slideDown(400, function(){
            $clicked.next().css({overflow:'visible'})
            STATE.is_animating = false;
          });
        });
      }

    });
  }

  document.gra_init && (document.gra_init = {
    aws_path: document.gra_init.aws_path,
    menu_loaded: menu_loaded,
    get: function(page, selector, cb, cb_fail){
      $('.activeMemberNav').first().find('span').after(STATE.$spinner);
      cb || (cb = page_loaded);
      $.ajax({
        url: document.gra_init.aws_path + page,
        type: 'get',
        crossDomain: true,
        dataType: 'html'
      }).then(function(data){
        cb(data, selector);
        $selector = $(selector);
        if($selector.hasClass('gra-menu-section')) return;
        $('html, body').stop().animate({
            scrollTop: $selector.offset().top
        }, 400);
      }).then(null, function(data){
        cb_fail && cb_fail(data);
      }).always(function(){
        STATE.$spinner.remove();
      });
    }
  });

  $('.gra-day-container .video-js').each(function(i, player){
    videojs(player, player_config).ready( player_init );
  });

}(jQuery));
