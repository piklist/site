<?php
/*  
Title: Validation
*/
?>

<?php echo $before_widget; ?>

  <?php echo $before_title; ?>
  
  <?php echo $after_title; ?>

    <?php piklist::pre($settings); ?>
    
<?php echo $after_widget; ?>
