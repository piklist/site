<?php
/*
Title: Conditions
Order: 80
Flow: User Test
Tab Order: 1
*/

  piklist('include_user_profile_fields', array(
    'meta_boxes' => array(
      'Conditional Fields'
      ,'Party Invite'
    )
  ));

  piklist('shared/code-locater', array(
    'location' => __FILE__
    ,'type' => 'Workflow Tab'
  ));

?>