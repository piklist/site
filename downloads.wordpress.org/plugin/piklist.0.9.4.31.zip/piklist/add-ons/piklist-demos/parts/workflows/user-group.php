<?php
/*
Title: Groups
Order: 50
Flow: User Test
*/

  piklist('include_user_profile_fields', array(
    'meta_boxes' => array(
      'Field Groups'
    )
  ));

  piklist('shared/code-locater', array(
    'location' => __FILE__
    ,'type' => 'Workflow Tab'
  ));

?>