<?php
/*
Title: General
Order: 20
Flow: User Test
Tab Order: 10
*/
   
  piklist('include_user_profile_fields', array(
    'meta_boxes' => array(
      'Editor'
    )
  ));

  piklist('shared/code-locater', array(
    'location' => __FILE__
    ,'type' => 'Workflow Tab'
  ));

?>