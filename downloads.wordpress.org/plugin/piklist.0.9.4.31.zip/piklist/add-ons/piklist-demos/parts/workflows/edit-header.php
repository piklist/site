<?php
/*
Flow: Edit Demo
Page: post.php, post-new.php, post-edit.php, admin.php
Post Type: piklist_demo
Header: true
Position: title
*/
?>

<h2><?php _e('Welcome to the Piklist Demo for custom post types.','piklist-demo'); ?></h2>
<p><?php _e('Click the Workflow Tabs to see sample field configurations you can easily build with Piklist.', 'piklist-demo'); ?></p>