<?php
/*
Title: Validation
Order: 70
Flow: User Test
*/

  piklist('include_user_profile_fields', array(
    'meta_boxes' => array(
      'Validation Fields'
    )
  ));

  piklist('shared/code-locater', array(
    'location' => __FILE__
    ,'type' => 'Workflow Tab'
  ));

?>