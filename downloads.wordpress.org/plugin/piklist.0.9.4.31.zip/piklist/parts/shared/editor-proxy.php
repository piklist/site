
<div style="display: none;">
  
  <?php wp_editor('', 'piklist-editor-proxy'); ?>

</div>

<script>

  (function($)
  {
    $('#wp-piklist-editor-proxy-wrap').remove();
  });

</script>