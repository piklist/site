<?php
/*
Title: Relate
Order: 100
Flow: Demo Workflow
Page: post.php, post-new.php
Post Type: piklist_demo
*/
?>


<div class="piklist-demo-highlight">

  <h3><?php _e('Piklist relate fields are the most powerful available. You can relate any object to any object.', 'piklist-demo'); ?></h3>

</div>