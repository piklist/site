<?php
/*
Title: Two Levels
Order: 20
Flow: Demo Workflow
Tab: Add more's
*/
?>

<div class="piklist-demo-highlight">

  <h3><?php _e('Your infinite repeater field.', 'piklist-demo'); ?></h3>

  <p>
    <?php _e('Piklist add more fields are the repeater field you always dreamed of. Group together as many fields as you want and make them repeat indefinitely. Or place an add more within an add more within an Add more ...', 'piklist-demo');?>
  </p>
  
</div>