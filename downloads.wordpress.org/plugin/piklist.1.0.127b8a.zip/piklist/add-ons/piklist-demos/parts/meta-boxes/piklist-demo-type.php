<?php
/*
Post Type: piklist_demo
Extend: piklist_demo_typediv
Extend Method: remove
Flow: Demo Workflow
Tab: All
*/