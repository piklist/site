<div class="piklist-tooltip dashicons dashicons-editor-help" data-piklist-tooltip="<?php echo esc_html($message); ?>">

  <span class="icon-help"></span>

</div>