<?php
/*
Shortcode: piklist_form
*/
  
  piklist('form', array(
    'form' => $form
    ,'add_on' => isset($add_on) ? $add_on : null
  ));