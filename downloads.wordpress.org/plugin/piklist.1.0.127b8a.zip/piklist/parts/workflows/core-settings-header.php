<?php
/*
Flow: Piklist Core Settings
Page: admin.php, piklist-core-settings
Header: true
Position: title
*/
